To run node project:-npm run dev
To run angular project:- ng serve
PORT=3000
MONGODB_URL=mongodb://127.0.0.1:27017/redis-api
